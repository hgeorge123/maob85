import json
import base64
import requests
import boto3
import os
from botocore.exceptions import ClientError

REGION = "us-east-1"

# LOAD SSM PARAMETERS
ssm_client = boto3.client("ssm", region_name=REGION)

param = ssm_client.get_parameter(Name="/prod/serverlessAuth/userPoolSecretName")
os.environ["USER_POOL_SECRET"] = param["Parameter"]["Value"]

param = ssm_client.get_parameter(Name="/prod/serverlessAuth/userPoolHostedUi")
os.environ["SIGN_IN_URL"] = param["Parameter"]["Value"].replace("login","logout")

param = ssm_client.get_parameter(Name="/prod/serverlessAuth/userPoolEndpoint")
os.environ["REVOKE_URL"] = param["Parameter"]["Value"]
REVOKE_URL = os.environ["REVOKE_URL"].replace("token", "revoke")



def handler(event, context):
    request = event["Records"][0]["cf"]["request"]
    headers = request["headers"]
    domainName = request["headers"]["host"][0]["value"]

    idTokenCookie = ""
    accessTokenCookie = ""
    refreshTokenCookie = ""

    # Check for the ID Token cookie
    for cookie in headers.get("cookie", []):
        cookiesList = cookie["value"].split(";")
        for subCookie in cookiesList:
            if "idToken" in subCookie:
                idTokenCookie = subCookie
            if "accessToken" in subCookie:
                accessTokenCookie = subCookie
            if "refreshToken" in subCookie:
                refreshTokenCookie = subCookie
                
    base64Bytes = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode("ascii"))
    encodedSecret = base64Bytes.decode("ascii")



    #test con refresh token
    print(refreshTokenCookie)
    #token = idTokenCookie.split("=")[1]
    token = refreshTokenCookie.replace("refreshToken=","").strip()
    print("Refresh",token)

    call_cognito(CLIENT_ID, token, encodedSecret)


    response = {
        "status": "307",
        "statusDescription": "Temporary Redirect",
        "headers": {
            "location": [
                {
                    "key": "location",
                    "value": os.environ["SIGN_IN_URL"] + "&prompt=login",
                },
            ],
            'cache-control': [{'key': 'Cache-Control', 'value': 'no-store'}]
            #"set-cookie": [
            #    {
            #        "key": "Set-Cookie",
            #        "value": idTokenCookie,
            #        "attributes": "Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0",
            #    },
            #    {
            #        "key": "Set-Cookie",
            #        "value": accessTokenCookie,
            #        "attributes": "Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0",
            #    },
            #    {
            #        "key": "Set-Cookie",
            #        "value": refreshTokenCookie,
            #        "attributes": "Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0",
            #    },
            #],
        },
    }

    return response

def call_cognito(clientId, token, encodedSecret):
    payload = {
        "client_id":clientId,
        "token":token,
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Basic {encodedSecret}",
    }

    resp = requests.post(REVOKE_URL, params=payload, headers=headers)
    print(resp.status_code)
    print(REVOKE_URL, payload, headers, resp)
    return resp

def get_secret():
    # Lambda@Edge doesn't support Environment Variables.
    secretName = SECRET_NAME
    regionName = REGION

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(service_name="secretsmanager", region_name=regionName)

    try:
        get_secret_value_response = client.get_secret_value(SecretId=secretName)
    except ClientError as e:
        raise e

    secret = get_secret_value_response["SecretString"]
    return secret

SECRET_NAME = os.environ["USER_POOL_SECRET"]
# Load Secrets and jwks outside of the handler
secret = json.loads(get_secret())
CLIENT_ID = secret["clientId"]
CLIENT_SECRET = secret["clientSecret"]